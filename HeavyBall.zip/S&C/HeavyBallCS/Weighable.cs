﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeavyBallCS
{
    public class Weighable : IWeighable
    {
        int weight;
        int index;
        public void setWeight(int w)
        {
            weight = w;
        }
        public int getWeight()
        {
            return weight;
        }
        public void setIndex(int i)
        {
            index = i;
        }
        public int getIndex()
        {
            return index;
        }
    }
}
