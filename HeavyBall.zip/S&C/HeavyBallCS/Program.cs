﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeavyBallCS
{
    /**
     * BalanceResults Enum	Meaning
        Left	The left set is heavier ( the sum of the weight of left objects
     * > the sum of the weight of the right objects)
        Right	The right set is heavier ( the sum of the weight of left objects 
     * < the sum of the weight of the right objects)
        Balanced	The two sets have equal weight
     *  ( the sum of the weight of left objects == the sum of the weight of the right objects)
     **/
    enum BalanceResults { Left, Right, Balanced };
 
    class Program
    {
        static void Main(string[] args)
        {
            int N = 8;
            int weight = 1;
            int heavyWeight = 2;
            Weighable[] arr = new Weighable[N];
         
            //intitalizing whole array with same weights, lets say 1
            for (int i = 0; i < N; i++)
            {
                arr[i] = new Weighable();
                arr[i].setIndex(i);
                arr[i].setWeight(weight);
            }
            
            //randomply placing heavy ball in this array
            Random rnd = new Random();
            int indexOfheavyBall = rnd.Next(0, N); // creates a number between 0 and N-1
            arr[indexOfheavyBall].setWeight(heavyWeight);
            Console.WriteLine("Original array: ");
            display(arr);
            
            //3. Defining HashSet by passing an Array of string to it
            // HashSet<Weighable> hSet = new HashSet<Weighable>(names);
            int calculatedIndexOfHeavyBallInArray = getIndex(arr, N,1);
            //calculatedIndexOfHeavyBallInArray should equal to indexOfheavyBall
            if (calculatedIndexOfHeavyBallInArray == -1)
            {
                Console.WriteLine("All balls are of same weight");
            }
            else
            {
                
                Console.WriteLine("Index of heavy ball: " + calculatedIndexOfHeavyBallInArray);
            }
            Console.ReadKey();
        }
        /**
         * Method to get index of heavy ball in the array
         */
        private static int getIndex(Weighable[] arr, int N, int passes)
        {
            Console.WriteLine("********************************Pass: " + passes+ "********************************");
            if (N ==1)
            {
                Console.WriteLine("Number of passes: " + passes);
                return arr[0].getIndex();
            }
            Weighable[] left;
            Weighable[] right;
            Weighable[] spared;
            BalanceResults result;
            if (N == 2)
            {
                left = new Weighable[1];
                right = new Weighable[1];
                left[0] = arr[0];
                left[0].setIndex(arr[0].getIndex());
                left[0].setWeight(arr[0].getWeight());

                right[0] = arr[1];
                result = Balance(left, right);
                Console.WriteLine("Number of passes: " + passes);
                //display arrays
                Console.Write("Left: "); display(left);
                Console.Write("Right: "); display(right);
                Console.WriteLine("Spared: ");  
                if (result == BalanceResults.Balanced)
                    return -1;//result not possible

                else if (result == BalanceResults.Left)
                    return left[0].getIndex();
                else
                    return right[0].getIndex();
            }       
            else
            {
                //there are >= 3 balls
                //divide array in 3 parts
                //weigh any two parts, if equal, heavy ball is in third
                //or in left or in right scale
                //logic is to remove maximum balls in each weighing
                int n = N;
                spared =arr;
                double f = n/3.0;
                //to devide array
                int factor = (int)(f + 0.5);
                Console.WriteLine("Factor : "+factor);
                left = getSubArray(arr, 0, factor - 1, factor);
                right = getSubArray(arr, factor, factor + factor-1, factor);
                spared = getSubArray(arr, factor + factor, arr.Length - 1, arr.Length-(2*factor));
                //display arrays
                Console.Write("Left: "); display(left);
                Console.Write("Right: "); display(right);
                Console.Write("Spared: "); display(spared);
                result = Balance(left, right);
                
                //if   search in spared
                if (result == BalanceResults.Balanced)
                    return getIndex(spared, spared.Length, ++passes);
                //if left is heavy, search in left
                else if (result == BalanceResults.Left)
                    return getIndex(left, left.Length, ++passes);
                else
                    //if right is heavy, search in right
                    return getIndex(right, right.Length, ++passes);
            } 
        }

        /**
         * Method to get subset of the array
         */
        private static Weighable[] getSubArray(Weighable[] arrIn, int beginIndex, int endIndex, int size)
        {
            Weighable[] arr = new Weighable[size];
            int index = 0;
            for (int i = beginIndex; i <= endIndex; i++)
            {
                //storing index
                arr[index] = new Weighable();
                arr[index].setIndex(arrIn[i].getIndex());
                arr[index].setWeight(arrIn[i].getWeight());
                index++;
            }
            return arr;
        }
        /**
         * Method
         * return Left	, Right or Balanced
     */
        private static BalanceResults Balance(Weighable[] left, Weighable[] right)
        {
            int leftSum = sum(left);
            int rightSum = sum(right);
            if (leftSum == rightSum)
                return BalanceResults.Balanced;
            else if (leftSum > rightSum)
                return BalanceResults.Left;
            else
              return  BalanceResults.Right;
        }

        /**
         * method to sum the weights in array
         */
        private static int sum(Weighable[] arr)
        {
            int sum = 0;
            for(int i=0;i<arr.Length;i++) {
                sum += arr[i].getWeight();
            }
            return sum;
        }

        /**
         * method to display array
         */
        private static void display(Weighable [] arr) { 
            for(int i=0;i<arr.Length;i++) {
                Console.Write("[" + arr[i].getIndex() + "]=" + arr[i].getWeight() + " ");
            }
             Console.WriteLine();
        }
    }
}
