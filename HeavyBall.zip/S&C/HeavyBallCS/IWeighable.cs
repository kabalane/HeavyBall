﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeavyBallCS
{
    public interface IWeighable
    {
        void setWeight(int w);
        int getWeight();
        void setIndex(int i);
        int getIndex();
    }
}
